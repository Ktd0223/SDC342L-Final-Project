# Requirements coverage

| Requirement | Implementation |
|---|---|
| MySQL backend and at least five related tables | Seven InnoDB tables in database/setup.sql with primary and foreign keys |
| Database user and password | Private config and least-privilege SQL account example |
| Five products or services and three complaint types | Seeded in setup.sql |
| Input formats, lengths, optional maximums and password complexity | Core/Validator.php and controller validation |
| Register and email/password customer login | AuthController and person/login views |
| Customer profile updates | AccountController::customer |
| Complaint service, category, description and image | ComplaintController::create and ImageRepository |
| Own complaints, notes, open or closed status | Dashboard and complaint details with ownership checks |
| Employee user ID/password login and password change | AuthController and AccountRepository |
| Technician assigned list and notes/analysis | ComplaintRepository and ComplaintController::detail |
| Resolve with date and required notes | Atomic transaction, server validation and database check |
| Admin customer listing and updates | AccountController customers/customer |
| Admin employee listing, add and update | AccountController employees/employee |
| Immutable employee user ID | UI display only and repository update whitelist |
| Open complaints with technicians and unassigned open list | Dashboard filters |
| Technician counts including zero and complaint assignment | LEFT JOIN workload query and assignment form |
| MVC and database objects | Seven entity classes, repositories, controllers and views |
| HTTPS, authentication and authorization | HTTPS gate, sessions, role and record ownership checks |
| File support | Private validated image storage, append-only error log and text export |
| Final status, tests and retrospective | Word documents in docs |

No claim is made that Week 2, Week 3 or Week 4 work was submitted on its original due date. The catch-up status report records the actual delivery date.
