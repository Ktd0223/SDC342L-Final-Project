# Database design

```mermaid
erDiagram
    customers ||--o{ complaints : submits
    employees o|--o{ complaints : assigned
    services ||--o{ complaints : concerns
    complaint_types ||--o{ complaints : categorizes
    complaints ||--o{ complaint_notes : has
    employees ||--o{ complaint_notes : writes
    complaints ||--o{ complaint_images : includes
```

| Table | Important fields | Relationships |
|---|---|---|
| customers | email 254, names 50, street 100, city 50, state 2, ZIP 10, phone 20, password hash 255 | complaints.customer_id |
| employees | immutable user_id 50, names 50, email 254, extension 10, role, password hash 255 | assigned employee and note author |
| services | unique name 100 | complaints.service_id |
| complaint_types | unique name 100 | complaints.complaint_type_id |
| complaints | description validated 20–5000, status, created date, nullable assignment, required resolution fields when closed | customer, service, type, employee |
| complaint_notes | note validated 1–5000, created date | complaint and employee |
| complaint_images | stored name 64, original name 255, MIME 32, byte size | complaint |

All primary keys are unsigned auto-increment integers. Foreign keys restrict removal of referenced records. Passwords are hashes, not plaintext. The five services and three categories are listed on the landing page and submission form. Each complaint starts open and unassigned. Closed complaints require a resolution date and nonempty resolution notes.
