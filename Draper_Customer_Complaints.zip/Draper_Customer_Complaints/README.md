# Draper Tech Care Customer Complaint Management

Kai Draper — PHP course project. Object-oriented PHP MVC with MySQL or MariaDB.

## Start here in XAMPP on Windows

1. Extract the entire `Draper_Customer_Complaints` folder to `C:\xampp\htdocs\Draper_Customer_Complaints`. Do not move individual PHP files out of their folders.
2. Start Apache and MySQL in the XAMPP Control Panel. Use PHP 8.1 or newer with PDO MySQL, mbstring, fileinfo, GD and sessions enabled. In `C:\xampp\php\php.ini`, enable `extension=gd`, `extension=mbstring`, and `extension=pdo_mysql` if needed, then restart Apache. Use `upload_max_filesize=5M`, `post_max_size=8M`, and `memory_limit=256M`.
3. Open phpMyAdmin locally and import `database/setup.sql` as a database administrator. This creates `draper_complaints`, seven related tables, five services and three complaint types. It does not drop existing data; only import once into a new database.
4. Edit the password in `database/create_db_user.example.sql` and import that script as administrator. It creates `complaint_app` with SELECT, INSERT and UPDATE privileges. Do not use a real personal password.
5. Copy `config/config.example.php` to `config/config.php`. Set its database password to match step 4. Keep `enforce_https` set to `true` for course submission. This private file is excluded from GitHub.
6. Open Command Prompt and run:

```bat
cd C:\xampp\htdocs\Draper_Customer_Complaints
C:\xampp\php\php.exe database\seed.php
```

The CLI creates `admin`, `tech1`, and `tech2` employee accounts and prints a different random initial password for each. Save those passwords securely. Running the tool again skips existing accounts and does not reset passwords. Customers register through the application. No default password is committed.

7. Open **https://localhost/Draper_Customer_Complaints/public/index.php**. Sign in with account type Employee, user ID `admin` and the password printed in step 6. Change the password from the navigation. Create a customer account using Create account.

## HTTPS in XAMPP

XAMPP commonly includes an Apache SSL configuration on port 443. Check `C:\xampp\apache\conf\httpd.conf` has these lines enabled:

```apache
LoadModule ssl_module modules/mod_ssl.so
Include conf/extra/httpd-ssl.conf
```

In `conf/extra/httpd-ssl.conf`, check that `Listen 443`, the SSL virtual host, and valid `SSLCertificateFile` and `SSLCertificateKeyFile` paths exist. Restart Apache and visit the HTTPS URL above. For a local development certificate, use a trusted local certificate for `localhost` or verify XAMPP's local certificate before accepting a local certificate warning. Never use an unverified certificate for a public site.

The application refuses plain HTTP with status 426 before processing forms or starting a session. HTTPS sessions use Secure, HttpOnly and SameSite=Lax cookies. For deployment, configure a trusted certificate and make `public/` the document root. The app deliberately does not trust forwarded HTTPS headers.

For isolated development only, `enforce_https=false` allows a PHP development server. Restore `true` before demonstration or submission. The PHP built-in server does not provide HTTPS.

## Suggested demonstration

1. Register as a customer and edit the profile.
2. Submit a laptop service complaint with a PNG or JPG image.
3. Sign out. Sign in as `admin`; view open and unassigned lists and the technician workload, including technicians with zero open complaints.
4. Open the complaint and assign it to `tech1`.
5. Sign in as `tech1`; open the assigned complaint and add analysis. Resolve it with a resolution date and resolution notes.
6. Sign in as the customer and verify the notes, image and closed status.
7. As administrator, add and edit an employee; confirm the user ID cannot be changed. Download the text summary.
8. Verify a second customer and `tech2` cannot open the first customer's complaint or image by changing the URL ID.

## Architecture

- `app/Models`: Database connection, seven entity classes, and repositories for account, lookup, complaint and image persistence. Query values use prepared statements.
- `app/Controllers`: Request validation and customer, employee, authentication and complaint workflows.
- `app/Views`: HTML and escaped page output; no SQL. CSS is in `public/assets/style.css`.
- `app/Core`: Authentication, authorization, validation, HTTP errors and private error logging.
- `database`: Schema, least-privilege account example and CLI seed tool.
- `storage/uploads`: Private randomized image names, re-encoded after MIME and dimension checks. Images are streamed only after ownership or role checks.
- `storage/logs`: Append-only error records without passwords, submitted fields or SQL text.
- `tests`: Repeatable HTTP integration tests for an isolated database.
- `docs`: Requirements mapping, test report, retrospective and updated project status.

Every data table is related through foreign keys. Complaint history is preserved; deletion is not exposed because the assignment requires adding and updating accounts and managing complaints. Employee IDs remain immutable. Employees with open assignments must be reassigned before their role can change. Self-demotion by the signed-in administrator is blocked.

## Testing

`tests/integration.py` is destructive only through its caller's database setup: use an empty disposable database, seed the three employee accounts with the same `COMPLAINT_SEED_PASSWORD`, start a development server, and run:

```text
python -m pip install requests Pillow
python tests/integration.py
```

Set `COMPLAINT_TEST_URL` if the URL is different, and `COMPLAINT_TEST_PASSWORD` to the seed password. The default test-only password in the runner is `TestingOnly!123`; it is never seeded unless explicitly supplied to the seed tool. The runner creates fictional accounts and complaints, changes `tech1`'s password, and expects an initially empty complaint table. It writes local JSON results excluded from Git. Reset the disposable database before rerunning. Do not run it against real customer data. See the test document for actual results and remaining Windows SSL checks.

## GitHub and submission

Create a repository named `Draper-Customer-Complaints` and upload this folder's contents, including `docs`, `database` and `tests`. Keep the folder layout. Do not upload `config/config.php`, real customer information, uploaded images, logs or passwords. Keep the repository private unless your instructor requires public access; invite the instructor if private.

The Week 5 submission consists of the repository URL, updated project plan, test description document and retrospective document. Review the retrospective in your own words and complete the local XAMPP checks before submitting. Earlier weekly progress has not been backdated.

## Troubleshooting

- HTTP 426 means use the HTTPS URL and enable Apache SSL.
- A setup error means check the database name, user, password, SQL import and PHP extensions. Private errors are logged by class and code in `storage/logs/application.log`.
- Ensure Apache can write to `storage/uploads`, `storage/logs`, and PHP's configured session directory.
- Image upload errors: check GD/fileinfo, the 5 MB limit, the 20 million pixel limit and php.ini post limits. A rejected upload does not save a partial complaint.
- Launching a PHP file with `file:///` will not execute PHP; use the XAMPP URL.
- Never use `/xampp/htdocs/` in the browser URL.
