<?php
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'draper_complaints',
    'db_user' => 'complaint_app',
    'db_password' => 'ChangeThisDatabasePassword!',
    'enforce_https' => true,
    'session_timeout' => 1800,
];
