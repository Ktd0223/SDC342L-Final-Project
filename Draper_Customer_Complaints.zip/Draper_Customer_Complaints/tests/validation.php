<?php
require __DIR__.'/../app/bootstrap.php';
use App\Core\Validator as V;
$passed=0;
function expect(string $name,callable $fn,bool $reject=false): void {
    global $passed;
    try { $fn(); if($reject) throw new RuntimeException('Expected rejection: '.$name); }
    catch (InvalidArgumentException $e) { if(!$reject) throw $e; }
    echo 'PASS '.$name.PHP_EOL;$passed++;
}
expect('Exact maximum text accepted',fn()=>V::text(['x'=>str_repeat('a',50)],'x','Text',1,50));
expect('Overlong text rejected',fn()=>V::text(['x'=>str_repeat('a',51)],'x','Text',1,50),true);
expect('Empty optional field accepted',fn()=>V::text(['x'=>''],'x','Optional',0,10));
expect('Optional maximum enforced',fn()=>V::text(['x'=>str_repeat('a',11)],'x','Optional',0,10),true);
expect('Multibyte characters counted correctly',fn()=>V::text(['x'=>str_repeat('é',50)],'x','Text',1,50));
expect('Password byte maximum enforced',fn()=>V::password(['password'=>str_repeat('é',40).'aA1!']),true);
expect('Strong password accepted',fn()=>V::password(['password'=>'CourseProject!123']));
expect('Array ID rejected',fn()=>V::id(['1']),true);
expect('Negative ID rejected',fn()=>V::id('-1'),true);
expect('Nonexistent leap date rejected',fn()=>V::date('2025-02-29'),true);
expect('Future date rejected',fn()=>V::date('2099-01-01'),true);
expect('Valid past date accepted',fn()=>V::date('2024-02-29'));
expect('Invalid employee level rejected',fn()=>V::employee(['email'=>'x@example.com','first_name'=>'X','last_name'=>'Y','extension'=>'','role'=>'Superuser'],false),true);
echo $passed.' validation checks passed'.PHP_EOL;
