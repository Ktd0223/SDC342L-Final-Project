<?php
declare(strict_types=1);
const ROOT = __DIR__ . '/..';
spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) === 0) {
        $file = __DIR__ . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
        if (is_file($file)) require $file;
    }
});
function e($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $route, array $params = []): string { return 'index.php?' . http_build_query(['route' => $route] + $params); }
function redirect(string $route, array $params = []): void { header('Location: ' . url($route, $params)); exit; }
function config(): array {
    static $config;
    if ($config === null) {
        $file = ROOT . '/config/config.php';
        if (!is_file($file)) throw new RuntimeException('Copy config/config.example.php to config/config.php and configure your database.');
        $config = require $file;
    }
    return $config;
}
function flash(string $message): void { $_SESSION['flash'] = $message; }
function render(string $view, array $data = []): void {
    extract($data, EXTR_SKIP);
    ob_start(); require ROOT . '/app/Views/' . $view . '.php'; $content = ob_get_clean();
    require ROOT . '/app/Views/layout.php';
}
function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function verify_csrf(): void {
    if (!is_string($_POST['csrf'] ?? null) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'])) {
        throw new App\Core\HttpException(403, 'Your form expired. Reload the page and try again.');
    }
}
function post_data(): array {
    $data = [];
    foreach ($_POST as $key => $value) {
        if (!is_string($value)) throw new InvalidArgumentException('Invalid form data.');
        $data[$key] = str_contains($key, 'password') ? $value : trim($value);
    }
    return $data;
}
function field(string $name, string $label, array $values = [], string $type = 'text', bool $required = true, int $max = 255): void {
    echo '<label>' . e($label) . '<input name="' . e($name) . '" type="' . e($type) . '" maxlength="' . $max . '" ' . ($required ? 'required ' : '') . 'value="' . ($type === 'password' ? '' : e($values[$name] ?? '')) . '"></label>';
}
