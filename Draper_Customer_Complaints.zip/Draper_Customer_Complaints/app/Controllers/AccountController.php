<?php
namespace App\Controllers;
use App\Core\{Auth,Validator,HttpException};
use App\Models\{AccountRepository,Database};
class AccountController {
    public function customers(): void {
        Auth::requireRole(['Administrator']);$accounts=(new AccountRepository())->all('customers');render('accounts',['accounts'=>$accounts,'kind'=>'customers','heading'=>'Customers']);
    }
    public function employees(): void {
        Auth::requireRole(['Administrator']);$accounts=(new AccountRepository())->all('employees');render('accounts',['accounts'=>$accounts,'kind'=>'employees','heading'=>'Employees']);
    }
    public function customer(bool $profile=false): void {
        $u=Auth::requireRole($profile?['Customer']:['Administrator']);$repo=new AccountRepository();$id=$profile?$u['id']:Validator::id($_GET['id']??'');
        $values=$repo->find('customers',$id);if (!$values) throw new HttpException(404,'Customer not found.');$error='';
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            try { $values=post_data();$repo->save('customers',Validator::person($values),$id);flash('Customer information saved.');redirect($profile?'profile':'customers'); }
            catch (\InvalidArgumentException $e) { $error=$e->getMessage(); }
            catch (\PDOException $e) { if ($e->getCode()!=='23000') throw $e;$error='That email is already used by another customer.'; }
        }
        render('person',['heading'=>$profile?'My profile':'Edit customer','values'=>$values,'error'=>$error,'registration'=>false]);
    }
    public function employee(): void {
        $u=Auth::requireRole(['Administrator']);$repo=new AccountRepository();$id=isset($_GET['id'])?Validator::id($_GET['id']):null;
        $values=$id?$repo->find('employees',$id):[];if ($id && !$values) throw new HttpException(404,'Employee not found.');$error='';$original=$values;
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            try {
                $values=post_data();$data=Validator::employee($values,$id===null);
                // Keep assigned technicians and the current administrator in their roles.
                if ($id && $original['role']!==$data['role']) {
                    if ($id===$u['id']) throw new \InvalidArgumentException('You cannot change your own administrator level.');
                    $s=Database::connection()->prepare("SELECT COUNT(*) FROM complaints WHERE assigned_employee_id=? AND status='open'");$s->execute([$id]);
                    if ((int)$s->fetchColumn()>0) throw new \InvalidArgumentException('Reassign open complaints before changing this technician to administrator.');
                }
                $repo->save('employees',$data,$id);flash('Employee saved.');redirect('employees');
            } catch (\InvalidArgumentException $e) { $error=$e->getMessage(); }
            catch (\PDOException $e) { if ($e->getCode()!=='23000') throw $e;$error='User ID or email is already in use.'; }
        }
        if ($id) $values['user_id']=$original['user_id'];
        render('employee',compact('values','error','id'));
    }
}
