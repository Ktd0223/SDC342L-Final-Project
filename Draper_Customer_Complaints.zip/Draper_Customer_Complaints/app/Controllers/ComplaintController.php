<?php
namespace App\Controllers;
use App\Core\{Auth,Validator,HttpException};
use App\Models\{ComplaintRepository,LookupRepository,ImageRepository,Database};
class ComplaintController {
    public function dashboard(): void {
        $u=Auth::requireRole(['Customer','Technician','Administrator']);$repo=new ComplaintRepository();$filter=$_GET['filter']??'all';
        if (!is_string($filter) || !in_array($filter,['all','open','unassigned'],true)) throw new \InvalidArgumentException('Invalid filter.');
        if ($u['role']!=='Administrator' && $filter==='unassigned') throw new HttpException(403,'Administrator access required.');
        $complaints=$repo->list($u,$filter);$technicians=$u['role']==='Administrator'?$repo->technicians():[];
        render('dashboard',compact('u','complaints','technicians','filter'));
    }
    public function create(): void {
        $u=Auth::requireRole(['Customer']);$lookups=new LookupRepository();$services=$lookups->all('services');$types=$lookups->all('complaint_types');$values=[];$error='';
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            $db=Database::connection();
            try {
                $values=post_data();$d=['description'=>Validator::text($values,'description','Description',20,5000),'service_id'=>Validator::id($values['service_id']??''),'complaint_type_id'=>Validator::id($values['complaint_type_id']??'')];
                if (!$lookups->exists('services',$d['service_id']) || !$lookups->exists('complaint_types',$d['complaint_type_id'])) throw new \InvalidArgumentException('Select a valid service and complaint type.');
                $db->beginTransaction();$id=(new ComplaintRepository())->create($d,$u['id']);(new ImageRepository())->upload($id,$_FILES['image']??[]);$db->commit();
                flash('Complaint submitted successfully.');redirect('complaint',['id'=>$id]);
            } catch (\InvalidArgumentException $e) { if ($db->inTransaction()) $db->rollBack();$error=$e->getMessage(); }
            catch (\Throwable $e) { if ($db->inTransaction()) $db->rollBack();throw $e; }
        }
        render('new_complaint',compact('values','error','services','types'));
    }
    public function detail(): void {
        $u=Auth::requireRole(['Customer','Technician','Administrator']);$id=Validator::id($_GET['id']??'');$repo=new ComplaintRepository();$complaint=$repo->get($id,$u);$error='';$values=[];
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            try {
                $values=post_data();$action=$values['action']??'';
                if ($action==='assign') {
                    Auth::requireRole(['Administrator']);$repo->assign($id,Validator::id($values['technician_id']??''));
                } elseif ($action==='update') {
                    Auth::requireRole(['Technician']);$note=Validator::text($values,'note','Technician notes',0,5000);$resolution=Validator::text($values,'resolution_notes','Resolution notes',0,5000);$date=Validator::text($values,'resolution_date','Resolution date',0,10);
                    $status=$values['status']??'';if (!in_array($status,['open','closed'],true)) throw new \InvalidArgumentException('Choose a valid status.');$resolve=$status==='closed';
                    if ($resolve) { $resolution=Validator::text($values,'resolution_notes','Resolution notes',1,5000);$date=Validator::date($date); }
                    elseif ($note==='') throw new \InvalidArgumentException('Enter technician notes or resolve the complaint.');
                    $repo->updateByTechnician($id,$u,['note'=>$note,'resolve'=>$resolve,'resolution_notes'=>$resolution,'resolution_date'=>$date]);
                } else throw new HttpException(400,'Invalid action.');
                flash('Complaint updated.');redirect('complaint',['id'=>$id]);
            } catch (\InvalidArgumentException $e) { $error=$e->getMessage(); }
        }
        $notes=$repo->notes($id);$images=$repo->images($id);$technicians=$u['role']==='Administrator'?$repo->technicians():[];
        render('complaint',compact('u','complaint','notes','images','technicians','error','values'));
    }
    public function export(): void {
        $u=Auth::requireRole(['Administrator']);$records=(new ComplaintRepository())->list($u);
        $fp=fopen('php://temp','w+');if (!$fp) throw new \RuntimeException('Export unavailable.');
        fwrite($fp,"Complaint summary export\nCreated ".gmdate('c')."\n\n");
        foreach ($records as $record) { $r=$record->toArray();fwrite($fp,'#'.$r['id'].' | '.$r['status'].' | '.$r['service_name'].' | '.$r['type_name'].' | Technician: '.($r['technician_name']?:'Unassigned')."\n"); }
        rewind($fp);header('Content-Type: text/plain; charset=UTF-8');header('Content-Disposition: attachment; filename="complaint-summary.txt"');fpassthru($fp);fclose($fp);
    }
}
