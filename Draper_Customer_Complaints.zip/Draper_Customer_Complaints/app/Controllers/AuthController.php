<?php
namespace App\Controllers;
use App\Core\{Auth,Validator};
use App\Models\AccountRepository;
class AuthController {
    public function login(): void {
        $error='';$values=[];
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            try {
                $values=post_data();$kind=($values['kind']??'')==='employees'?'employees':'customers';
                $login=Validator::text($values,'login','Login',1,254);$password=Validator::text($values,'password','Password',1,255);
                $repo=new AccountRepository();$record=$repo->credentials($kind,$login);
                if (!$record || !password_verify($password,$record['password_hash'])) {
                    usleep(250000);throw new \InvalidArgumentException('Incorrect login or password.');
                }
                Auth::login($record,$kind);redirect('dashboard');
            } catch (\InvalidArgumentException $e) { $error=$e->getMessage(); }
        }
        render('login',compact('error','values'));
    }
    public function register(): void {
        $error='';$values=[];
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            try {
                $values=post_data();$data=Validator::person($values);$data['password_hash']=password_hash(Validator::password($values),PASSWORD_DEFAULT);
                $repo=new AccountRepository();$id=$repo->save('customers',$data);Auth::login($repo->find('customers',$id),'customers');flash('Your account is ready.');redirect('dashboard');
            } catch (\InvalidArgumentException $e) { $error=$e->getMessage(); }
            catch (\PDOException $e) { if ($e->getCode()!=='23000') throw $e; $error='An account with that email already exists.'; }
        }
        render('person', ['heading'=>'Create your account','values'=>$values,'error'=>$error,'registration'=>true]);
    }
    public function password(): void {
        $user=Auth::requireRole(['Customer','Technician','Administrator']);$error='';
        if ($_SERVER['REQUEST_METHOD']==='POST') {
            try {
                $d=post_data();$repo=new AccountRepository();$r=$repo->find($user['kind'],$user['id']);
                if (!password_verify($d['current_password']??'',$r['password_hash'])) throw new \InvalidArgumentException('Current password is incorrect.');
                $p=Validator::password($d,'new_password');if ($p!==($d['confirm_password']??'')) throw new \InvalidArgumentException('New passwords must match.');
                $repo->changePassword($user['kind'],$user['id'],password_hash($p,PASSWORD_DEFAULT));session_regenerate_id(true);flash('Password changed.');redirect('dashboard');
            } catch (\InvalidArgumentException $e) { $error=$e->getMessage(); }
        }
        render('password',compact('error'));
    }
}
