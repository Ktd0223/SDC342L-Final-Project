<?php
namespace App\Models;
class ComplaintNote {
    private array $data;
    public function __construct(array $data) { $this->data = $data; }
    public function getId() { return $this->data['id'] ?? null; }
    public function getComplaintId() { return $this->data['complaint_id'] ?? null; }
    public function getEmployeeId() { return $this->data['employee_id'] ?? null; }
    public function getNote() { return $this->data['note'] ?? null; }
    public function getCreatedAt() { return $this->data['created_at'] ?? null; }
    public function toArray(): array { return $this->data; }
}
