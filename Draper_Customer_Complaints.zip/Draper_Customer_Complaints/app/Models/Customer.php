<?php
namespace App\Models;
class Customer {
    private array $data;
    public function __construct(array $data) { $this->data = $data; }
    public function getId() { return $this->data['id'] ?? null; }
    public function getEmail() { return $this->data['email'] ?? null; }
    public function getFirstName() { return $this->data['first_name'] ?? null; }
    public function getLastName() { return $this->data['last_name'] ?? null; }
    public function getStreet() { return $this->data['street'] ?? null; }
    public function getCity() { return $this->data['city'] ?? null; }
    public function getState() { return $this->data['state'] ?? null; }
    public function getZip() { return $this->data['zip'] ?? null; }
    public function getPhone() { return $this->data['phone'] ?? null; }
    public function toArray(): array { return $this->data; }
}
