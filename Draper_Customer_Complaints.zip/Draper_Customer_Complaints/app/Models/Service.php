<?php
namespace App\Models;
class Service {
    private array $data;
    public function __construct(array $data) { $this->data = $data; }
    public function getId() { return $this->data['id'] ?? null; }
    public function getName() { return $this->data['name'] ?? null; }
    public function toArray(): array { return $this->data; }
}
