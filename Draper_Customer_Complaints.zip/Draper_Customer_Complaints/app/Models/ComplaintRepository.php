<?php
namespace App\Models;
use App\Core\HttpException;
class ComplaintRepository {
    private \PDO $db;
    private const JOIN = 'SELECT c.*, s.name service_name, t.name type_name, CONCAT(u.first_name," ",u.last_name) customer_name, CONCAT(e.first_name," ",e.last_name) technician_name FROM complaints c JOIN services s ON s.id=c.service_id JOIN complaint_types t ON t.id=c.complaint_type_id JOIN customers u ON u.id=c.customer_id LEFT JOIN employees e ON e.id=c.assigned_employee_id';
    public function __construct() { $this->db=Database::connection(); }
    public function list(array $user,string $filter='all'): array {
        $where=[];$args=[];
        if ($user['role']==='Customer') { $where[]='c.customer_id=?';$args[]=$user['id']; }
        if ($user['role']==='Technician') { $where[]='c.assigned_employee_id=?';$args[]=$user['id']; }
        if ($filter==='open' || $filter==='unassigned') $where[]="c.status='open'";
        if ($filter==='unassigned') $where[]='c.assigned_employee_id IS NULL';
        $s=$this->db->prepare(self::JOIN . ($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY c.id DESC');$s->execute($args);
        return array_map(fn($r)=>new Complaint($r),$s->fetchAll());
    }
    public function get(int $id,array $user,bool $lock=false): Complaint {
        $s=$this->db->prepare(self::JOIN.' WHERE c.id=?'.($lock?' FOR UPDATE':''));$s->execute([$id]);$r=$s->fetch();
        if (!$r) throw new HttpException(404,'Complaint not found.');
        if (($user['role']==='Customer' && (int)$r['customer_id']!==$user['id']) || ($user['role']==='Technician' && (int)$r['assigned_employee_id']!==$user['id'])) throw new HttpException(403,'You do not have permission to view this complaint.');
        return new Complaint($r);
    }
    public function create(array $data,int $customerId): int {
        $s=$this->db->prepare('INSERT INTO complaints (customer_id,service_id,complaint_type_id,description) VALUES (?,?,?,?)');$s->execute([$customerId,$data['service_id'],$data['complaint_type_id'],$data['description']]);return (int)$this->db->lastInsertId();
    }
    public function notes(int $id): array {
        $s=$this->db->prepare('SELECT n.*,CONCAT(e.first_name," ",e.last_name) author FROM complaint_notes n JOIN employees e ON e.id=n.employee_id WHERE n.complaint_id=? ORDER BY n.id');$s->execute([$id]);return array_map(fn($r)=>new ComplaintNote($r),$s->fetchAll());
    }
    public function images(int $id): array {
        $s=$this->db->prepare('SELECT * FROM complaint_images WHERE complaint_id=? ORDER BY id');$s->execute([$id]);return array_map(fn($r)=>new ComplaintImage($r),$s->fetchAll());
    }
    public function updateByTechnician(int $id,array $user,array $data): void {
        $this->db->beginTransaction();
        try {
            $c=$this->get($id,$user,true);
            if ($c->getStatus()==='closed') throw new \InvalidArgumentException('This complaint is already resolved.');
            if ($data['note']!=='') {
                $s=$this->db->prepare('INSERT INTO complaint_notes (complaint_id,employee_id,note) VALUES (?,?,?)');$s->execute([$id,$user['id'],$data['note']]);
            }
            if ($data['resolve']) {
                if ($data['resolution_date'] < substr($c->getCreatedAt(),0,10)) throw new \InvalidArgumentException('Resolution date cannot precede the complaint date.');
                $s=$this->db->prepare("UPDATE complaints SET status='closed',resolution_date=?,resolution_notes=? WHERE id=?");$s->execute([$data['resolution_date'],$data['resolution_notes'],$id]);
            }
            $this->db->commit();
        } catch (\Throwable $e) { $this->db->rollBack();throw $e; }
    }
    public function technicians(): array {
        $s=$this->db->query("SELECT e.id,e.first_name,e.last_name,COUNT(c.id) open_count FROM employees e LEFT JOIN complaints c ON c.assigned_employee_id=e.id AND c.status='open' WHERE e.role='Technician' GROUP BY e.id,e.first_name,e.last_name ORDER BY e.last_name,e.first_name");return $s->fetchAll();
    }
    public function assign(int $id,int $tech): void {
        $s=$this->db->prepare("SELECT id FROM employees WHERE id=? AND role='Technician'");$s->execute([$tech]);if (!$s->fetch()) throw new \InvalidArgumentException('Choose a valid technician.');
        $s=$this->db->prepare("UPDATE complaints SET assigned_employee_id=? WHERE id=? AND status='open'");$s->execute([$tech,$id]);
        // MySQL may report zero when the same technician is selected; check state.
        $s=$this->db->prepare("SELECT id FROM complaints WHERE id=? AND status='open' AND assigned_employee_id=?");$s->execute([$id,$tech]);if (!$s->fetch()) throw new \InvalidArgumentException('Only open complaints can be assigned.');
    }
}
