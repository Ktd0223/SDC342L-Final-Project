<?php
namespace App\Models;
class ComplaintImage {
    private array $data;
    public function __construct(array $data) { $this->data = $data; }
    public function getId() { return $this->data['id'] ?? null; }
    public function getComplaintId() { return $this->data['complaint_id'] ?? null; }
    public function getStoredName() { return $this->data['stored_name'] ?? null; }
    public function getOriginalName() { return $this->data['original_name'] ?? null; }
    public function getMimeType() { return $this->data['mime_type'] ?? null; }
    public function getSizeBytes() { return $this->data['size_bytes'] ?? null; }
    public function toArray(): array { return $this->data; }
}
