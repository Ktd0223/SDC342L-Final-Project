<?php
namespace App\Models;
class LookupRepository {
    public function all(string $table): array {
        $class = match ($table) { 'services' => Service::class, 'complaint_types' => ComplaintType::class, default => throw new \InvalidArgumentException('Invalid lookup.') };
        return array_map(fn($r)=>new $class($r),Database::connection()->query("SELECT * FROM $table ORDER BY name")->fetchAll());
    }
    public function exists(string $table,int $id): bool {
        if (!in_array($table,['services','complaint_types'],true)) throw new \InvalidArgumentException('Invalid lookup.');
        $s=Database::connection()->prepare("SELECT id FROM $table WHERE id=?");$s->execute([$id]);return (bool)$s->fetch();
    }
}
