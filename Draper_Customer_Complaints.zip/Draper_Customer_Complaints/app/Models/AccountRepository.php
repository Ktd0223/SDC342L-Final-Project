<?php
namespace App\Models;
class AccountRepository {
    private \PDO $db;
    public function __construct() { $this->db = Database::connection(); }
    private function table(string $kind): string {
        if (!in_array($kind, ['customers', 'employees'], true)) throw new \InvalidArgumentException('Invalid account type.');
        return $kind;
    }
    public function find(string $kind, int $id): ?array {
        $s=$this->db->prepare('SELECT * FROM ' . $this->table($kind) . ' WHERE id=?'); $s->execute([$id]); return $s->fetch() ?: null;
    }
    public function credentials(string $kind, string $login): ?array {
        $column = $kind === 'customers' ? 'email' : 'user_id';
        $s=$this->db->prepare('SELECT * FROM ' . $this->table($kind) . " WHERE $column=?"); $s->execute([$login]); return $s->fetch() ?: null;
    }
    public function all(string $kind): array {
        $class = $kind === 'customers' ? Customer::class : Employee::class;
        return array_map(fn($row) => new $class($row), $this->db->query('SELECT * FROM ' . $this->table($kind) . ' ORDER BY last_name,first_name')->fetchAll());
    }
    public function save(string $kind, array $data, ?int $id = null): int {
        $table=$this->table($kind);
        $allowed = $kind === 'customers' ? ['email','first_name','last_name','street','city','state','zip','phone','password_hash'] : ['first_name','last_name','email','extension','role','password_hash'];
        if ($kind === 'employees' && $id === null) $allowed[]='user_id';
        $data=array_intersect_key($data,array_flip($allowed));
        if ($id === null) {
            $keys=array_keys($data);$s=$this->db->prepare('INSERT INTO '.$table.' ('.implode(',',$keys).') VALUES ('.implode(',',array_fill(0,count($keys),'?')).')');$s->execute(array_values($data));return (int)$this->db->lastInsertId();
        }
        $s=$this->db->prepare('UPDATE '.$table.' SET '.implode(',',array_map(fn($k)=>"$k=?",array_keys($data))).' WHERE id=?');$s->execute([...array_values($data),$id]);return $id;
    }
    public function changePassword(string $kind,int $id,string $hash): void { $this->save($kind,['password_hash'=>$hash],$id); }
}
