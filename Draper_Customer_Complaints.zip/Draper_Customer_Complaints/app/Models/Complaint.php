<?php
namespace App\Models;
class Complaint {
    private array $data;
    public function __construct(array $data) { $this->data = $data; }
    public function getId() { return $this->data['id'] ?? null; }
    public function getCustomerId() { return $this->data['customer_id'] ?? null; }
    public function getServiceId() { return $this->data['service_id'] ?? null; }
    public function getComplaintTypeId() { return $this->data['complaint_type_id'] ?? null; }
    public function getDescription() { return $this->data['description'] ?? null; }
    public function getStatus() { return $this->data['status'] ?? null; }
    public function getAssignedEmployeeId() { return $this->data['assigned_employee_id'] ?? null; }
    public function getCreatedAt() { return $this->data['created_at'] ?? null; }
    public function getResolutionDate() { return $this->data['resolution_date'] ?? null; }
    public function getResolutionNotes() { return $this->data['resolution_notes'] ?? null; }
    public function toArray(): array { return $this->data; }
}
