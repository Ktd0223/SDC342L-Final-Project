<?php
namespace App\Models;
class Employee {
    private array $data;
    public function __construct(array $data) { $this->data = $data; }
    public function getId() { return $this->data['id'] ?? null; }
    public function getUserId() { return $this->data['user_id'] ?? null; }
    public function getEmail() { return $this->data['email'] ?? null; }
    public function getFirstName() { return $this->data['first_name'] ?? null; }
    public function getLastName() { return $this->data['last_name'] ?? null; }
    public function getExtension() { return $this->data['extension'] ?? null; }
    public function getRole() { return $this->data['role'] ?? null; }
    public function toArray(): array { return $this->data; }
}
