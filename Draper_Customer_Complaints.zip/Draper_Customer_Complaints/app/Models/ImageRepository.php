<?php
namespace App\Models;
use App\Core\HttpException;
class ImageRepository {
    public function upload(int $complaintId,array $file): void {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return;
        if (($file['error'] ?? -1)!==UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '')) throw new \InvalidArgumentException('The image could not be uploaded.');
        $size=filesize($file['tmp_name']);
        if (!$size || $size>5*1024*1024) throw new \InvalidArgumentException('Image must be no larger than 5 MB.');
        $info=@getimagesize($file['tmp_name']);$mime=(new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if (!$info || !in_array($mime,['image/jpeg','image/png'],true) || $info['mime']!==$mime || $info[0]*$info[1]>20000000) throw new \InvalidArgumentException('Upload a valid JPG or PNG with at most 20 million pixels.');
        $name=bin2hex(random_bytes(24)).($mime==='image/png'?'.png':'.jpg');
        $original=mb_substr(basename(str_replace('\\','/',$file['name'])),0,255);
        $path=ROOT.'/storage/uploads/'.$name;
        // Re-encode to discard appended payloads and metadata.
        $image=$mime==='image/png'?@imagecreatefrompng($file['tmp_name']):@imagecreatefromjpeg($file['tmp_name']);
        if (!$image) throw new \InvalidArgumentException('Image could not be decoded.');
        if ($mime==='image/png') { imagealphablending($image,false);imagesavealpha($image,true);$ok=imagepng($image,$path); } else $ok=imagejpeg($image,$path,90);
        imagedestroy($image);
        if (!$ok) throw new \RuntimeException('Image storage unavailable.');
        try { $s=Database::connection()->prepare('INSERT INTO complaint_images (complaint_id,stored_name,original_name,mime_type,size_bytes) VALUES (?,?,?,?,?)');$s->execute([$complaintId,$name,$original,$mime,filesize($path)]); }
        catch (\Throwable $e) { @unlink($path);throw $e; }
    }
    public function serve(int $id,array $user): void {
        $s=Database::connection()->prepare('SELECT * FROM complaint_images WHERE id=?');$s->execute([$id]);$r=$s->fetch();
        if (!$r) throw new HttpException(404,'Image not found.');
        (new ComplaintRepository())->get((int)$r['complaint_id'],$user);
        $path=ROOT.'/storage/uploads/'.$r['stored_name'];if (!is_file($path)) throw new HttpException(404,'Image file not found.');
        header('Content-Type: '.$r['mime_type']);header('Content-Length: '.filesize($path));header('Cache-Control: private, no-store');header('Content-Disposition: inline; filename="complaint-image"');readfile($path);
    }
}
