<?php
namespace App\Core;
class Logger {
    public static function error(\Throwable $error): void {
        // No submitted values, passwords, SQL statements or exception messages in logs.
        $record = gmdate('c') . ' ' . get_class($error) . ' code=' . $error->getCode() . PHP_EOL;
        if (@file_put_contents(ROOT . '/storage/logs/application.log', $record, FILE_APPEND | LOCK_EX) === false) {
            error_log('Complaint application could not write its private error log.');
        }
    }
}
