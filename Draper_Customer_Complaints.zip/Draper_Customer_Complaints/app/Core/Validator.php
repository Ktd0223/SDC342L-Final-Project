<?php
namespace App\Core;
class Validator {
    public static function text(array $d, string $key, string $label, int $min, int $max): string {
        $value = $d[$key] ?? '';
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value) < $min || mb_strlen($value) > $max || str_contains($value, "\0")) throw new \InvalidArgumentException("$label must contain $min to $max characters.");
        return $value;
    }
    public static function email(array $d): string {
        $v = strtolower(self::text($d, 'email', 'Email', 3, 254));
        if (!filter_var($v, FILTER_VALIDATE_EMAIL)) throw new \InvalidArgumentException('Enter a valid email address.');
        return $v;
    }
    public static function password(array $d, string $key = 'password'): string {
        $p = self::text($d, $key, 'Password', 12, 72);
        if (strlen($p) > 72 || !preg_match('/[A-Z]/', $p) || !preg_match('/[a-z]/', $p) || !preg_match('/[0-9]/', $p) || !preg_match('/[^a-zA-Z0-9]/', $p)) throw new \InvalidArgumentException('Use 12 to 72 bytes with uppercase, lowercase, a number and a symbol.');
        return $p;
    }
    public static function id($value): int {
        if (!is_string($value) && !is_int($value)) throw new \InvalidArgumentException('Invalid record number.');
        $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if ($id === false) throw new \InvalidArgumentException('Invalid record number.');
        return $id;
    }
    public static function person(array $d): array {
        $v = ['email' => self::email($d)];
        foreach (['first_name' => 50, 'last_name' => 50, 'street' => 100, 'city' => 50, 'state' => 2, 'zip' => 10, 'phone' => 20] as $k => $max) $v[$k] = self::text($d, $k, ucwords(str_replace('_', ' ', $k)), 1, $max);
        $v['state'] = strtoupper($v['state']);
        if (!preg_match('/^[A-Z]{2}$/D', $v['state'])) throw new \InvalidArgumentException('State must contain two letters.');
        if (!preg_match('/^[0-9]{5}(-[0-9]{4})?$/D', $v['zip'])) throw new \InvalidArgumentException('ZIP must be 12345 or 12345-6789.');
        if (!preg_match('/^\+?[0-9 ()-]{7,20}$/D', $v['phone']) || strlen(preg_replace('/\D/', '', $v['phone'])) < 7) throw new \InvalidArgumentException('Enter a valid phone number.');
        return $v;
    }
    public static function employee(array $d, bool $new): array {
        $v = ['email' => self::email($d)];
        foreach (['first_name' => 50, 'last_name' => 50, 'extension' => 10] as $key => $max) $v[$key] = self::text($d, $key, ucfirst(str_replace('_', ' ', $key)), $key === 'extension' ? 0 : 1, $max);
        if ($v['extension'] !== '' && !preg_match('/^[0-9]{1,10}$/D', $v['extension'])) throw new \InvalidArgumentException('Extension must contain digits only.');
        $v['role'] = $d['role'] ?? '';
        if (!in_array($v['role'], ['Administrator', 'Technician'], true)) throw new \InvalidArgumentException('Select a valid employee level.');
        if ($new) {
            $v['user_id'] = self::text($d, 'user_id', 'User ID', 3, 50);
            if (!preg_match('/^[a-zA-Z0-9_.-]+$/D', $v['user_id'])) throw new \InvalidArgumentException('User ID may contain letters, numbers, underscore, dot or dash.');
            $v['password_hash'] = password_hash(self::password($d), PASSWORD_DEFAULT);
        }
        return $v;
    }
    public static function date(string $date): string {
        $dt = \DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if (!$dt || $dt->format('Y-m-d') !== $date || $date > date('Y-m-d')) throw new \InvalidArgumentException('Enter a valid resolution date that is not in the future.');
        return $date;
    }
}
