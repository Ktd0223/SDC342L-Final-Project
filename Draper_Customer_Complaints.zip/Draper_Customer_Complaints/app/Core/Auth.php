<?php
namespace App\Core;
use App\Models\AccountRepository;
class Auth {
    public static function user(): ?array { return $_SESSION['user'] ?? null; }
    public static function requireRole(array $roles): array {
        $u = self::user();
        if (!$u) redirect('login');
        // Reload the role so changes by an administrator apply immediately.
        $repo = new AccountRepository();
        $record = $repo->find($u['kind'], $u['id']);
        if (!$record) { self::logout(); redirect('login'); }
        $u['role'] = $u['kind'] === 'customers' ? 'Customer' : $record['role'];
        $u['name'] = $record['first_name'] . ' ' . $record['last_name'];
        $_SESSION['user'] = $u;
        if (!in_array($u['role'], $roles, true)) throw new HttpException(403, 'You do not have permission to access this page.');
        return $u;
    }
    public static function login(array $record, string $kind): void {
        session_regenerate_id(true);
        $_SESSION['user'] = ['id' => (int)$record['id'], 'kind' => $kind, 'role' => $kind === 'customers' ? 'Customer' : $record['role'], 'name' => $record['first_name'] . ' ' . $record['last_name']];
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    public static function logout(): void {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', ['expires' => time()-42000, 'path' => $p['path'], 'secure' => $p['secure'], 'httponly' => true, 'samesite' => 'Lax']);
        }
        session_destroy();
    }
}
