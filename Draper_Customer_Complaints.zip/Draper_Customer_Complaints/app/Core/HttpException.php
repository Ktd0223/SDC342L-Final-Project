<?php
namespace App\Core;
class HttpException extends \RuntimeException {
    public int $status;
    public function __construct(int $status, string $message) {
        $this->status = $status;
        parent::__construct($message);
    }
}
