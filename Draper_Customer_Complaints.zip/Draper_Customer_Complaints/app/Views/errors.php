<?php if (!empty($error)): ?><p role="alert" class="error"><?=e($error)?></p><?php endif; ?>
