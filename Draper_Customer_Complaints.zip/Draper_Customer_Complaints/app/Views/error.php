<p class="eyebrow">SUPPORT PORTAL</p><h1><?=e($heading)?></h1><p><?=e($message)?></p><a class="button secondary" href="<?=e(url('home'))?>">Return to overview</a>
