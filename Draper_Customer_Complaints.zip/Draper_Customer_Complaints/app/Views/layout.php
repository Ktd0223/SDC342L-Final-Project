<?php $current=\App\Core\Auth::user(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Draper Tech Care | Complaint Management</title><link rel="stylesheet" href="assets/style.css"></head>
<body><a class="skip" href="#main">Skip to content</a><header><a class="brand" href="<?=e(url('home'))?>"><span class="brand-icon">D</span> Draper Tech Care</a><span class="tagline">CUSTOMER SUPPORT PORTAL</span></header>
<div class="shell"><aside><p class="nav-label">WORKSPACE</p><nav aria-label="Main navigation"><a href="<?=e(url('home'))?>">Overview</a>
<?php if ($current): ?><a href="<?=e(url('dashboard'))?>">Complaints</a>
<?php if ($current['role']==='Customer'): ?><a href="<?=e(url('new'))?>">Submit a complaint</a><a href="<?=e(url('profile'))?>">My profile</a><?php endif; ?>
<?php if ($current['role']==='Administrator'): ?><a href="<?=e(url('customers'))?>">Customers</a><a href="<?=e(url('employees'))?>">Employees</a><a href="<?=e(url('export'))?>">Export summary</a><?php endif; ?>
<a href="<?=e(url('password'))?>">Change password</a><form method="post" action="<?=e(url('logout'))?>"><?=csrf()?><button class="link-button">Sign out</button></form>
<?php else: ?><a href="<?=e(url('login'))?>">Sign in</a><a href="<?=e(url('register'))?>">Create account</a><?php endif; ?></nav>
<div class="aside-bottom"><?php if ($current): ?><strong><?=e($current['name'])?></strong><br><?=e($current['role'])?><?php else: ?>A clear path from<br>issue to resolution.<?php endif; ?></div></aside>
<main id="main"><?php if (isset($_SESSION['flash'])): ?><p class="notice" role="status"><?=e($_SESSION['flash'])?></p><?php unset($_SESSION['flash']); endif; ?><?=$content?></main></div><footer>Kai Draper · PHP Customer Complaint Course Project</footer></body></html>
