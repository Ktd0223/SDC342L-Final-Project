<?php
declare(strict_types=1);
ini_set('display_errors','0');
require __DIR__.'/../app/bootstrap.php';
use App\Core\{Auth,HttpException,Logger};
use App\Controllers\{AuthController,AccountController,ComplaintController};
try {
    $config=config();$https=isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off';
    // Only an explicit local development override may allow HTTP.
    if ($config['enforce_https'] && !$https) {
        http_response_code(426);render('error',['heading'=>'HTTPS is required','message'=>'Open this application using https://localhost and configure Apache SSL as described in README.md.']);exit;
    }
    if ($https) header('Strict-Transport-Security: max-age=31536000');
    header("Content-Security-Policy: default-src 'self'; img-src 'self'; style-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'");
    header('X-Content-Type-Options: nosniff');header('Referrer-Policy: same-origin');header('Cache-Control: no-store');
    ini_set('session.use_strict_mode','1');ini_set('session.use_only_cookies','1');
    session_name('complaint_session');session_set_cookie_params(['path'=>rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'])), '/').'/', 'secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);if (!session_start()) throw new RuntimeException('Session storage unavailable.');
    if (isset($_SESSION['last_activity']) && time()-$_SESSION['last_activity']>$config['session_timeout']) { Auth::logout();redirect('login'); }
    $_SESSION['last_activity']=time();
    $route=$_GET['route']??'home';if (!is_string($route)) throw new HttpException(400,'Invalid route.');
    if (!in_array($_SERVER['REQUEST_METHOD'],['GET','POST'],true)) throw new HttpException(405,'Method not allowed.');
    if ($_SERVER['REQUEST_METHOD']==='POST') verify_csrf();
    switch ($route) {
        case 'home': render('home');break;
        case 'login': (new AuthController())->login();break;
        case 'register': (new AuthController())->register();break;
        case 'password': (new AuthController())->password();break;
        case 'logout': if ($_SERVER['REQUEST_METHOD']!=='POST') throw new HttpException(405,'Use the sign out button.');Auth::logout();redirect('home');break;
        case 'dashboard': (new ComplaintController())->dashboard();break;
        case 'new': (new ComplaintController())->create();break;
        case 'complaint': (new ComplaintController())->detail();break;
        case 'profile': (new AccountController())->customer(true);break;
        case 'customers': (new AccountController())->customers();break;
        case 'customer': (new AccountController())->customer();break;
        case 'employees': (new AccountController())->employees();break;
        case 'employee': (new AccountController())->employee();break;
        case 'image': $u=Auth::requireRole(['Customer','Technician','Administrator']);(new App\Models\ImageRepository())->serve(App\Core\Validator::id($_GET['id']??''),$u);break;
        case 'export': (new ComplaintController())->export();break;
        default: throw new HttpException(404,'Page not found.');
    }
} catch (HttpException $e) {
    http_response_code($e->status);render('error',['heading'=>'Request could not be completed','message'=>$e->getMessage()]);
} catch (InvalidArgumentException $e) {
    http_response_code(400);render('error',['heading'=>'Check your request','message'=>$e->getMessage()]);
} catch (Throwable $e) {
    Logger::error($e);http_response_code(500);render('error',['heading'=>'Application setup or service issue','message'=>'Check your database configuration, import database/setup.sql, and ensure storage folders are writable. See README.md for setup steps.']);
}
