-- Change BOTH the password below and config/config.php before use.
-- Import as a MySQL administrator AFTER setup.sql.
CREATE USER IF NOT EXISTS 'complaint_app'@'localhost' IDENTIFIED BY 'ChangeThisDatabasePassword!';
GRANT SELECT, INSERT, UPDATE ON draper_complaints.* TO 'complaint_app'@'localhost';
-- The application does not delete historical complaint records or manage schema.
