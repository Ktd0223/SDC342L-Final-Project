<?php
// CLI only: php database/seed.php
if (PHP_SAPI!=='cli') { http_response_code(404);exit; }
require __DIR__.'/../app/bootstrap.php';
use App\Models\AccountRepository;
use App\Core\Validator;
try {
    $repo=new AccountRepository();
    foreach ([['admin','Administrator','Kai','Draper'],['tech1','Technician','Alex','Rivera'],['tech2','Technician','Jordan','Lee']] as [$login,$role,$first,$last]) {
        if ($repo->credentials('employees',$login)) { echo "$login already exists; skipped.\n";continue; }
        $password=getenv('COMPLAINT_SEED_PASSWORD') ?: bin2hex(random_bytes(8)).'aA!9';
        Validator::password(['password'=>$password]);
        $repo->save('employees',['user_id'=>$login,'role'=>$role,'first_name'=>$first,'last_name'=>$last,'email'=>$login.'@example.com','extension'=>'','password_hash'=>password_hash($password,PASSWORD_DEFAULT)]);
        echo "Created $role $login | Initial password: $password\n";
    }
    echo "Save initial passwords securely. Sign in as Employee. Change them after login.\n";
} catch (Throwable $e) { fwrite(STDERR,"Seed failed. Check config and database setup.\n");exit(1); }
