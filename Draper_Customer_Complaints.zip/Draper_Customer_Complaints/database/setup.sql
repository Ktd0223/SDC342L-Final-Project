-- Import into a NEW database with a MySQL administrator (phpMyAdmin root locally).
-- Does not drop existing tables or records. For a clean reset, drop the database manually first.
CREATE DATABASE IF NOT EXISTS draper_complaints CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE draper_complaints;
CREATE TABLE customers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 email VARCHAR(254) NOT NULL UNIQUE,
 first_name VARCHAR(50) NOT NULL,last_name VARCHAR(50) NOT NULL,
 street VARCHAR(100) NOT NULL,city VARCHAR(50) NOT NULL,state CHAR(2) NOT NULL,
 zip VARCHAR(10) NOT NULL,phone VARCHAR(20) NOT NULL,password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE employees (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,user_id VARCHAR(50) NOT NULL UNIQUE,
 first_name VARCHAR(50) NOT NULL,last_name VARCHAR(50) NOT NULL,email VARCHAR(254) NOT NULL UNIQUE,
 extension VARCHAR(10) NOT NULL DEFAULT '',role ENUM('Administrator','Technician') NOT NULL,
 password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE services (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE complaint_types (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE complaints (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,customer_id INT UNSIGNED NOT NULL,
 service_id INT UNSIGNED NOT NULL,complaint_type_id INT UNSIGNED NOT NULL,
 description TEXT NOT NULL,status ENUM('open','closed') NOT NULL DEFAULT 'open',
 assigned_employee_id INT UNSIGNED NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 resolution_date DATE NULL,resolution_notes TEXT NULL,
 FOREIGN KEY(customer_id) REFERENCES customers(id),FOREIGN KEY(service_id) REFERENCES services(id),
 FOREIGN KEY(complaint_type_id) REFERENCES complaint_types(id),FOREIGN KEY(assigned_employee_id) REFERENCES employees(id),
 CONSTRAINT valid_resolution CHECK(status='open' OR (resolution_date IS NOT NULL AND resolution_notes IS NOT NULL AND CHAR_LENGTH(TRIM(resolution_notes))>0)),
 INDEX(status,assigned_employee_id)
) ENGINE=InnoDB;
CREATE TABLE complaint_notes (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,complaint_id INT UNSIGNED NOT NULL,employee_id INT UNSIGNED NOT NULL,
 note TEXT NOT NULL,created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(complaint_id) REFERENCES complaints(id),FOREIGN KEY(employee_id) REFERENCES employees(id)
) ENGINE=InnoDB;
CREATE TABLE complaint_images (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,complaint_id INT UNSIGNED NOT NULL,
 stored_name VARCHAR(64) NOT NULL UNIQUE,original_name VARCHAR(255) NOT NULL,mime_type VARCHAR(32) NOT NULL,size_bytes INT UNSIGNED NOT NULL,
 FOREIGN KEY(complaint_id) REFERENCES complaints(id)
) ENGINE=InnoDB;
INSERT INTO services(name) VALUES ('Laptop repair'),('Desktop repair'),('Network setup'),('Software installation'),('Data backup');
INSERT INTO complaint_types(name) VALUES ('Service Quality'),('Billing Issue'),('Warranty Issue');
-- Accounts are created by the CLI seed tool with real password hashes; no public setup endpoint exists.
